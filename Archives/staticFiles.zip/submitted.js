function submit() {
    window.location.href = "submitted.html";
}